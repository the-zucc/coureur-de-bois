package characteristic;

import animator.Animator;

public interface Animatable {
	Animator getAnimator();
}
