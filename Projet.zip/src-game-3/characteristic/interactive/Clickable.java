package characteristic.interactive;

import javafx.scene.input.MouseEvent;

public interface Clickable {
	public void onClick(MouseEvent me);
}
