package util;

public interface StopCondition {
	boolean shouldStop();
}
