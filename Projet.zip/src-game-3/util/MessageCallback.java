package util;

public interface MessageCallback {
    public abstract void run(Object... params);
}
